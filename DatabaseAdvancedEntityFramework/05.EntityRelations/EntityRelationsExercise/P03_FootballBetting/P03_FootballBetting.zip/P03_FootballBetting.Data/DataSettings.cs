﻿namespace P03_FootballBetting.Data
{
    public class DataSettings
    {
        public const string DefaultConnection = @"Server=.\SQLEXPRESS01;Database=FootballBookmakerSystem;Integrated Security=True";
    }
}
