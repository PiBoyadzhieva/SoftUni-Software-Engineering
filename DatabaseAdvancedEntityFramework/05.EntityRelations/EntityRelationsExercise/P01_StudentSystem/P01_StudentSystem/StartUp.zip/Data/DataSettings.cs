﻿namespace P01_StudentSystem.Data
{
    public class DataSettings
    {
        public const string DefaultConnection = @"Server=.\SQLEXPRESS01;Database=StudentSystem;Integrated Security=True";
    }
}
